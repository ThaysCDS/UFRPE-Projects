from BancoDeDados import DBEscola


#classe que abriga o CRUD da Turma
class Turmas(object):


    def __init__(self, idturma=0, codturma="", periodoturma="",
                 coddiscturma="", cpfprofturma="", cpfalunoturma=""):
        self.info = {}
        self.idturma = idturma
        self.codturma = codturma
        self.periodoturma = periodoturma
        self.coddiscturma = coddiscturma
        self.cpfprofturma = cpfprofturma
        self.cpfalunoturma = cpfalunoturma


    # funcao para inserir uma turma no banco de dados
    def insertTurma(self):
        dbTurma = DBEscola()
        try:

            c = dbTurma.conexao.cursor()

            c.execute("insert into turmas (codturma, periodoturma, coddiscturma,cpfprofturma, cpfalunoturma) "
                      "values('" + self.codturma + "', '" +
            self.periodoturma + "', '" + self.coddiscturma + "', '" +
            self.cpfprofturma + "', '" + self.cpfalunoturma + "' )")

            dbTurma.conexao.commit()
            c.close()

            return "Turma cadastrada com sucesso!"
        except:
            return "Ocorreu um erro na inserção da turma"


    # funcao para atualizar uma turma do banco de dados
    def updateTurma(self):
        dbTurma = DBEscola()
        try:

            c = dbTurma.conexao.cursor()

            c.execute("update turmas set codturma = '" + self.codturma + "',periodoturma = '" + self.periodoturma + "', coddiscturma = '" + self.coddiscturma + "', cpfprofturma = '" + self.cpfprofturma + "', cpfalunoturma = '" + self.cpfalunoturma +"' where idturma = " + self.idturma + " ")

            dbTurma.conexao.commit()
            c.close()

            return "Turma atualizada com sucesso!"
        except:
            return "Ocorreu um erro na alteração da turma"


    # funcao para deletar uma turma do banco de dados
    def deleteTurma(self):
        dbTurma = DBEscola()
        try:

            c = dbTurma.conexao.cursor()

            c.execute("delete from turmas where idturma = " + self.idturma + " ")

            dbTurma.conexao.commit()
            c.close()

            return "Turma excluída com sucesso!"
        except:
            return "Ocorreu um erro na exclusão da turma"


    # funcao para selecionar uma turma do banco de dados
    def selectTurma(self, idturma):
        dbTurma = DBEscola()
        try:

            c = dbTurma.conexao.cursor()

            c.execute("select * from turmas where idturma = " + idturma + "  ")

            for linha in c:
                self.idturma = linha[0]
                self.codturma = linha[1]
                self.periodoturma = linha[2]
                self.coddiscturma = linha[3]
                self.cpfprofturma = linha[4]
                self.cpfalunoturma = linha[5]

            c.close()

            return "Busca feita com sucesso!"
        except:
            return "Ocorreu um erro na busca da turma"