from Turmas import Turmas
from tkinter import *


class Application:
    def __init__(self, master=None):
        self.fonte = ("Verdana", "8")

        # criando os layouts para alocar os elementos da interface
        self.container1 = Frame(master)
        self.container1["pady"] = 10
        self.container1.pack()
        self.container2 = Frame(master)
        self.container2["padx"] = 20
        self.container2["pady"] = 5
        self.container2.pack()
        self.container3 = Frame(master)
        self.container3["padx"] = 20
        self.container3["pady"] = 5
        self.container3.pack()
        self.container4 = Frame(master)
        self.container4["padx"] = 20
        self.container4["pady"] = 5
        self.container4.pack()
        self.container5 = Frame(master)
        self.container5["padx"] = 20
        self.container5["pady"] = 5
        self.container5.pack()
        self.container6 = Frame(master)
        self.container6["padx"] = 20
        self.container6["pady"] = 5
        self.container6.pack()
        self.container7 = Frame(master)
        self.container7["padx"] = 20
        self.container7["pady"] = 5
        self.container7.pack()
        self.container8 = Frame(master)
        self.container8["padx"] = 20
        self.container8["pady"] = 10
        self.container8.pack()
        self.container9 = Frame(master)
        self.container9["pady"] = 15
        self.container9.pack()

        # definindo os elementos da interface
        self.tituloturma = Label(self.container1, text="Informe os dados :")
        self.tituloturma["font"] = ("Calibri", "9", "bold")
        self.tituloturma.pack()

        # ----------------------------

        self.lblidturma = Label(self.container2,
                                text="idTurma:", font=self.fonte, width=10)
        self.lblidturma.pack(side=LEFT)

        self.txtidturma = Entry(self.container2)
        self.txtidturma["width"] = 10
        self.txtidturma["font"] = self.fonte
        self.txtidturma.pack(side=LEFT)

        self.btnBuscarturma = Button(self.container2, text="Buscar",
                                     font=self.fonte, width=10)
        self.btnBuscarturma["command"] = self.buscarTurma
        self.btnBuscarturma.pack(side=RIGHT)

        # ----------------------------

        self.lblcodturma = Label(self.container3, text="Codigo da turma:",
                                 font=self.fonte, width=10)
        self.lblcodturma.pack(side=LEFT)

        self.txtcodturma = Entry(self.container3)
        self.txtcodturma["width"] = 25
        self.txtcodturma["font"] = self.fonte
        self.txtcodturma.pack(side=LEFT)

        # ----------------------------

        self.lblperiodoturma = Label(self.container4, text="Periodo:",
                                     font=self.fonte, width=10)
        self.lblperiodoturma.pack(side=LEFT)

        self.txtperiodoturma = Entry(self.container4)
        self.txtperiodoturma["width"] = 25
        self.txtperiodoturma["font"] = self.fonte
        self.txtperiodoturma.pack(side=LEFT)

        # ----------------------------

        self.lblcoddiscturma = Label(self.container5, text="Codigo da disciplina:",
                                     font=self.fonte, width=10)
        self.lblcoddiscturma.pack(side=LEFT)

        self.txtcoddiscturma = Entry(self.container5)
        self.txtcoddiscturma["width"] = 25
        self.txtcoddiscturma["font"] = self.fonte
        self.txtcoddiscturma.pack(side=LEFT)

        # ----------------------------

        self.lblcpfprofturma = Label(self.container6, text="CPF do professor:",
                                     font=self.fonte, width=10)
        self.lblcpfprofturma.pack(side=LEFT)

        self.txtcpfalunoturma = Entry(self.container6)
        self.txtcpfalunoturma["width"] = 25
        self.txtcpfalunoturma["font"] = self.fonte
        self.txtcpfalunoturma.pack(side=LEFT)

        # ----------------------------

        self.txtcpfprofturma = Entry(self.container7)
        self.txtcpfprofturma["width"] = 25
        self.txtcpfprofturma["font"] = self.fonte
        self.txtcpfprofturma.pack(side=RIGHT)

        self.lblcpfalunoturma = Label(self.container7, text="CPF do aluno:",
                                      font=self.fonte, width=10)
        self.lblcpfalunoturma.pack(side=LEFT)

        # ----------------------------

        self.bntInsertturma = Button(self.container8, text="Inserir", font=self.fonte, width=12)
        self.bntInsertturma["command"] = self.inserirTurma
        self.bntInsertturma.pack(side=LEFT)

        self.bntAlterarturma = Button(self.container8, text="Alterar", font=self.fonte, width=12)
        self.bntAlterarturma["command"] = self.alterarTurma
        self.bntAlterarturma.pack(side=LEFT)

        self.bntExcluirturma = Button(self.container8, text="Excluir", font=self.fonte, width=12)
        self.bntExcluirturma["command"] = self.excluirTurma
        self.bntExcluirturma.pack(side=LEFT)

        self.bntSair = Button(self.container8, text="Sair", font=self.fonte, width=12)
        self.bntSair["command"] = self.irMenuT
        self.bntSair.pack(side=LEFT)

        # ----------------------------

        self.lblmsgturma = Label(self.container9, text="")
        self.lblmsgturma["font"] = ("Verdana", "9", "italic")
        self.lblmsgturma.pack()

    # agrupando a interface ao banco de dados

    def irMenuT(self):
        exit()

    def inserirTurma(self):
        turmaa = Turmas()

        turmaa.codturma = self.txtcodturma.get()
        turmaa.periodoturma = self.txtperiodoturma.get()
        turmaa.coddiscturma = self.txtcoddiscturma.get()
        turmaa.cpfprofturma = self.txtcpfprofturma.get()
        turmaa.cpfalunoturma = self.txtcpfalunoturma.get()

        self.lblmsgturma["text"] = turmaa.insertTurma()

        self.txtidturma.delete(0, END)
        self.txtcodturma.delete(0, END)
        self.txtperiodoturma.delete(0, END)
        self.txtcoddiscturma.delete(0, END)
        self.txtcpfprofturma.delete(0, END)
        self.txtcpfalunoturma.delete(0, END)

    def alterarTurma(self):
        turmaa = Turmas()

        turmaa.idturma = self.txtidturma.get()
        turmaa.codturma = self.txtcodturma.get()
        turmaa.periodoturma = self.txtperiodoturma.get()
        turmaa.coddiscturma = self.txtcoddiscturma.get()
        turmaa.cpfprofturma = self.txtcpfprofturma.get()
        turmaa.cpfalunoturma = self.txtcpfalunoturma.get()

        self.lblmsgturma["text"] = turmaa.updateTurma()

        self.txtidturma.delete(0, END)
        self.txtcodturma.delete(0, END)
        self.txtperiodoturma.delete(0, END)
        self.txtcoddiscturma.delete(0, END)
        self.txtcpfprofturma.delete(0, END)
        self.txtcpfalunoturma.delete(0, END)

    def excluirTurma(self):
        turmaa = Turmas()

        turmaa.idturma = self.txtidturma.get()

        self.lblmsgturma["text"] = turmaa.deleteTurma()

        self.txtidturma.delete(0, END)
        self.txtcodturma.delete(0, END)
        self.txtperiodoturma.delete(0, END)
        self.txtcoddiscturma.delete(0, END)
        self.txtcpfprofturma.delete(0, END)
        self.txtcpfalunoturma.delete(0, END)

    def buscarTurma(self):
        turmaa = Turmas()

        idturma = self.txtidturma.get()

        self.lblmsgturma["text"] = turmaa.selectTurma(idturma)

        self.txtidturma.delete(0, END)
        self.txtidturma.insert(INSERT, turmaa.idturma)

        self.txtcodturma.delete(0, END)
        self.txtcodturma.insert(INSERT, turmaa.codturma)

        self.txtperiodoturma.delete(0, END)
        self.txtperiodoturma.insert(INSERT, turmaa.periodoturma)

        self.txtcoddiscturma.delete(0, END)
        self.txtcoddiscturma.insert(INSERT, turmaa.coddiscturma)

        self.txtcpfprofturma.delete(0, END)
        self.txtcpfprofturma.insert(INSERT, turmaa.cpfprofturma)

        self.txtcpfalunoturma.delete(0, END)
        self.txtcpfalunoturma.insert(INSERT, turmaa.cpfalunoturma)


root = Tk()
Application(root)
root.mainloop()
