from BancoDeDados import DBEscola


#classe que abriga o CRUD das disciplinas
class Disciplinas(object):
    def __init__(self, iddisc=0, nomedisc="", codigodisc=""):
        self.info = {}
        self.iddisc = iddisc
        self.nomedisc = nomedisc
        self.codigodisc = codigodisc


    #funcao para inserir uma disciplina no banco de dados
    def insertDisciplina(self):
        dbDisciplina = DBEscola()
        try:

            c = dbDisciplina.conexao.cursor()

            c.execute("""INSERT INTO disciplinas (nomedisc, codigodisc) 
            VALUES (?,?)
            """, (self.nomedisc, self.codigodisc))

            #c.execute("insert into disciplinas (nomedisc, cpfaluno) values('" + self.nomedisc + "', '" +
            #self.codigodisc + "')")

            dbDisciplina.conexao.commit()

            print('Dados inseridos com sucesso.')

            c.close()

            return "Disciplina cadastrada com sucesso!"
        except:
            return "Ocorreu um erro na inserção da disciplina"


    # funcao para atualizar uma disciplina do banco de dados
    def updateDisciplina(self):
        dbDisciplina = DBEscola()
        try:

            c = dbDisciplina.conexao.cursor()

            c.execute("""UPDATE disciplinas SET nomedisc = ?, codigodisc = ? WHERE iddisc = ? """,
                      (self.nomedisc, self.codigodisc, self.iddisc))

           # c.execute("update disciplinas set nomedisc = '" + self.nomedisc + "', codigodisc = '" + self.codigodisc + "',"
            #                                                            "' where iddisc = " + self.iddisc + " ")

            dbDisciplina.conexao.commit()
            c.close()

            return "Disciplina atualizada com sucesso!"
        except:
            return "Ocorreu um erro na alteração da disciplina"


    ##funcao para deletar uma disciplina do banco de dados
    def deleteDisciplina(self):
        dbDisciplina = DBEscola()
        try:

            c = dbDisciplina.conexao.cursor()

            c.execute("delete from disciplinas where iddisc = " + self.iddisc + " ")

            dbDisciplina.conexao.commit()
            c.close()

            return "Disciplina excluída com sucesso!"
        except:
            return "Ocorreu um erro na exclusão da disciplina"


    # funcao para selecionar uma disciplina do banco de dados
    def selectDisciplina(self, iddisc):
        dbDisciplina = DBEscola()
        try:

            c = dbDisciplina.conexao.cursor()

            c.execute("select * from disciplinas where iddisc = " + iddisc + "  ")

            for linha in c:
                self.iddisc = linha[0]
                self.nomedisc = linha[1]
                self.codigodisc = linha[2]

            c.close()

            return "Busca feita com sucesso!"
        except:
            return "Ocorreu um erro na busca da disciplina"