from BancoDeDados import DBEscola


# classe que abriga o CRUD dos professores
class Professores(object):
    def __init__(self, idprof=0, nomeprof="", cpfprof="", departamentoprof=""):
        self.info = {}
        self.idprof = idprof
        self.nomeprof = nomeprof
        self.cpfprof = cpfprof
        self.departamentoprof = departamentoprof

    # funcao para inserir um professor no banco de dados
    def insertProfessor(self):
        dbProf = DBEscola()
        try:

            c = dbProf.conexao.cursor()

            c.execute("""INSERT INTO professor (nomeprof, cpfprof, departamentoprof)  
                       VALUES (?,?,?)
                       """, (self.nomeprof, self.cpfprof, self.departamentoprof))

            # c.execute("insert into professor (nomeprof, cpfprof, departamentoprof) values('" + self.nomeprof + "', '" +
            # self.cpfprof + self.departamentoprof + "' )")

            dbProf.conexao.commit()
            c.close()

            return "Professor cadastrado com sucesso!"
        except:
            return "Ocorreu um erro na inserção do professor"

    # funcao para atualizar um professor do banco de dados
    def updateProfessor(self):
        dbProf = DBEscola()
        try:

            c = dbProf.conexao.cursor()

            c.execute("""UPDATE professor SET nomeprof = ?, cpfprof = ?, departamentoprof = ? WHERE idprof = ? """,
                      (self.nomeprof, self.cpfprof, self.departamentoprof, self.idprof))

            #c.execute("update professor set nomeprof = '" + self.nomeprof + "', cpfprof = '" + self.cpfprof + "', "
            #                                                                                                  "departamentoprof = '" + self.departamentoprof + "', "
            #                                                                                                                                                  "' where idprof = " + self.idprof + " ")

            dbProf.conexao.commit()
            c.close()

            return "Professor atualizado com sucesso!"
        except:
            return "Ocorreu um erro na alteração do professor"

    ##funcao para deletar um professor do banco de dados
    def deleteProfessor(self):
        dbProf = DBEscola()
        try:

            c = dbProf.conexao.cursor()

            c.execute("delete from professor where idprof = " + self.idprof + " ")

            dbProf.conexao.commit()
            c.close()

            return "Professor excluído com sucesso!"
        except:
            return "Ocorreu um erro na exclusão do professor"

    # funcao para selecionar um professor do banco de dados
    def selectProfessor(self, idprof):
        dbProf = DBEscola()
        try:

            c = dbProf.conexao.cursor()

            c.execute("select * from professor where idprof = " + idprof + "  ")

            for linha in c:
                self.idprof = linha[0]
                self.nomeprof = linha[1]
                self.cpfprof = linha[2]
                self.departamentoprof = linha[3]

            c.close()

            return "Busca feita com sucesso!"
        except:
            return "Ocorreu um erro na busca do professor"
