from BancoDeDados import DBEscola


# classe que abriga o CRUD dos Alunos
class Alunos(object):
    def __init__(self, idaluno=0, nomealuno="", cpfaluno=""):
        self.info = {}
        self.idaluno = idaluno
        self.nomealuno = nomealuno
        self.cpfaluno = cpfaluno

    # funcao para inserir um aluno no banco de dados
    def insertAluno(self):
        dbAlunos = DBEscola()
        try:

            c = dbAlunos.conexao.cursor()

            c.execute("insert into alunos (nomealuno, cpfaluno) values('" + self.nomealuno + "', '" +
                      self.cpfaluno + "')")

            dbAlunos.conexao.commit()
            c.close()

            return "Aluno cadastrado com sucesso!"
        except:
            return "Ocorreu um erro na inserção do aluno"

    # funcao para atualizar um aluno do banco de dados
    def updateAluno(self):
        dbAlunos = DBEscola()
        try:
            c = dbAlunos.conexao.cursor()

            c.execute("""UPDATE alunos SET nomealuno = ?, cpfaluno = ? WHERE idaluno = ? """,
                      (self.nomealuno, self.cpfaluno, self.idaluno))

            dbAlunos.conexao.commit()
            c.close()

            return "Aluno atualizado com sucesso!"
        except:
            return "Ocorreu um erro na alteração do aluno"

    # funcao para deletar um aluno do banco de dados
    def deleteAluno(self):
        dbAlunos = DBEscola()
        try:

            c = dbAlunos.conexao.cursor()

            c.execute("delete from alunos where idaluno = " + self.idaluno + " ")

            dbAlunos.conexao.commit()
            c.close()

            return "Aluno excluído com sucesso!"
        except:
            return "Ocorreu um erro na exclusão do aluno"

    # funcao para selecionar um aluno do banco de dados
    def selectAluno(self, idaluno):
        dbAlunos = DBEscola()
        try:

            c = dbAlunos.conexao.cursor()

            c.execute("select * from alunos where idaluno = " + idaluno + "  ")

            for linha in c:
                self.idaluno = linha[0]
                self.nomealuno = linha[1]
                self.cpfaluno = linha[2]

            c.close()

            return "Busca feita com sucesso!"
        except:
            return "Ocorreu um erro na busca do aluno"
