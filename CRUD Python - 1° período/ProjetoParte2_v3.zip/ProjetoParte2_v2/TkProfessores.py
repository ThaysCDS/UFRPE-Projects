from Professores import Professores
from tkinter import *


class Application:
    def __init__(self, master=None):
        self.fonte = ("Verdana", "8")

        # criando os layouts para alocar os elementos da interface
        self.container1 = Frame(master)
        self.container1["pady"] = 10
        self.container1.pack()
        self.container2 = Frame(master)
        self.container2["padx"] = 20
        self.container2["pady"] = 5
        self.container2.pack()
        self.container3 = Frame(master)
        self.container3["padx"] = 20
        self.container3["pady"] = 5
        self.container3.pack()
        self.container4 = Frame(master)
        self.container4["padx"] = 20
        self.container4["pady"] = 5
        self.container4.pack()
        self.container5 = Frame(master)
        self.container5["padx"] = 20
        self.container5["pady"] = 5
        self.container5.pack()
        self.container6 = Frame(master)
        self.container6["padx"] = 20
        self.container6["pady"] = 10
        self.container6.pack()
        self.container7 = Frame(master)
        self.container7["pady"] = 15
        self.container7.pack()

        # definindo os elementos da interface
        self.tituloprof = Label(self.container1, text="Informe os dados :")
        self.tituloprof["font"] = ("Calibri", "9", "bold")
        self.tituloprof.pack()

        self.lblidprof = Label(self.container2, text="idProf:", font=self.fonte, width=10)
        self.lblidprof.pack(side=LEFT)

        self.txtidprof = Entry(self.container2)
        self.txtidprof["width"] = 10
        self.txtidprof["font"] = self.fonte
        self.txtidprof.pack(side=LEFT)

        self.btnBuscarprof = Button(self.container2, text="Buscar", font=self.fonte, width=10)
        self.btnBuscarprof["command"] = self.buscarProf
        self.btnBuscarprof.pack(side=RIGHT)

        self.lblnomeprof = Label(self.container3, text="Nome:", font=self.fonte, width=10)
        self.lblnomeprof.pack(side=LEFT)

        self.txtnomeprof = Entry(self.container3)
        self.txtnomeprof["width"] = 25
        self.txtnomeprof["font"] = self.fonte
        self.txtnomeprof.pack(side=LEFT)

        self.lblcpfprof = Label(self.container4, text="CPF:", font=self.fonte, width=10)
        self.lblcpfprof.pack(side=LEFT)

        self.txtcpfprof = Entry(self.container4)
        self.txtcpfprof["width"] = 25
        self.txtcpfprof["font"] = self.fonte
        self.txtcpfprof.pack(side=LEFT)

        self.lbldepartamentoprof = Label(self.container5, text="Departamento:", font=self.fonte, width=10)
        self.lbldepartamentoprof.pack(side=LEFT)

        self.txtdepartamentoprof = Entry(self.container5)
        self.txtdepartamentoprof["width"] = 25
        self.txtdepartamentoprof["font"] = self.fonte
        self.txtdepartamentoprof.pack(side=LEFT)

        self.bntInsertprof = Button(self.container6, text="Inserir", font=self.fonte, width=12)
        self.bntInsertprof["command"] = self.inserirProf
        self.bntInsertprof.pack(side=LEFT)

        self.bntAlterarprof = Button(self.container6, text="Alterar", font=self.fonte, width=12)
        self.bntAlterarprof["command"] = self.alterarProf
        self.bntAlterarprof.pack(side=LEFT)

        self.bntExcluirprof = Button(self.container6, text="Excluir", font=self.fonte, width=12)
        self.bntExcluirprof["command"] = self.excluirProf
        self.bntExcluirprof.pack(side=LEFT)

        self.lblmsgprof = Label(self.container7, text="")
        self.lblmsgprof["font"] = ("Verdana", "9", "italic")
        self.lblmsgprof.pack()

    # agrupando a interface ao banco de dados
    def inserirProf(self):
        professorr = Professores()

        professorr.nomeprof = self.txtnomeprof.get()
        professorr.cpfprof = self.txtcpfprof.get()
        professorr.departamentoprof = self.txtdepartamentoprof.get()

        self.lblmsgprof["text"] = professorr.insertProfessor()

        self.txtidprof.delete(0, END)
        self.txtnomeprof.delete(0, END)
        self.txtcpfprof.delete(0, END)
        self.txtdepartamentoprof.delete(0, END)

    def alterarProf(self):
        professorr = Professores()

        professorr.idprof = self.txtidprof.get()
        professorr.nomeprof = self.txtnomeprof.get()
        professorr.cpfprof = self.txtcpfprof.get()
        professorr.departamentoprof = self.txtdepartamentoprof.get()

        self.lblmsgprof["text"] = professorr.updateProfessor()

        self.txtidprof.delete(0, END)
        self.txtnomeprof.delete(0, END)
        self.txtcpfprof.delete(0, END)
        self.txtdepartamentoprof.delete(0, END)

    def excluirProf(self):
        professorr = Professores()

        professorr.idprof = self.txtidprof.get()

        self.lblmsgprof["text"] = professorr.deleteProfessor()

        self.txtidprof.delete(0, END)
        self.txtnomeprof.delete(0, END)
        self.txtcpfprof.delete(0, END)
        self.txtdepartamentoprof.delete(0, END)

    def buscarProf(self):
        professorr = Professores()

        idprof = self.txtidprof.get()

        self.lblmsgprof["text"] = professorr.selectProfessor(idprof)

        self.txtidprof.delete(0, END)
        self.txtidprof.insert(INSERT, professorr.idprof)

        self.txtnomeprof.delete(0, END)
        self.txtnomeprof.insert(INSERT, professorr.nomeprof)

        self.txtcpfprof.delete(0, END)
        self.txtcpfprof.insert(INSERT, professorr.cpfprof)

        self.txtdepartamentoprof.delete(0, END)
        self.txtdepartamentoprof.insert(INSERT, professorr.departamentoprof)


root = Tk()
Application(root)
root.mainloop()
