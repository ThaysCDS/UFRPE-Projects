from tkinter import *
import TkProfessores
import TkAlunos
import TkTurmas
import TkDisciplinas


class Application:
    def __init__(self, master=None):
        self.fonte = ("Verdana", "8")

        self.container1 = Frame(master)
        self.container1["pady"] = 10
        self.container1.pack()
        self.titulo = Label(self.container1, text="Menu principal")
        self.titulo["font"] = ("Calibri", "9", "bold")
        self.titulo.pack()

        self.bntProf = Button(self.container1, text="Professor", font=self.fonte, width=12)
        self.bntProf["command"] = self.dProfessor
        self.bntProf.pack(side=BOTTOM)

        self.bntAluno = Button(self.container1, text="Aluno", font=self.fonte, width=12)
        self.bntAluno["command"] = self.dAluno
        self.bntAluno.pack(side=BOTTOM)

        self.bntDisc = Button(self.container1, text="Disciplina", font=self.fonte, width=12)
        self.bntDisc["command"] = self.dDisciplina
        self.bntDisc.pack(side=BOTTOM)

        self.bntTurm = Button(self.container1, text="Turma", font=self.fonte, width=12)
        self.bntTurm["command"] = self.dTurma
        self.bntTurm.pack(side=BOTTOM)

        self.bntRela = Button(self.container1, text="Relatório", font=self.fonte, width=12)
        self.bntRela["command"] = self.dRelatorio
        self.bntRela.pack(side=BOTTOM)

        self.bntSair = Button(self.container1, text="Sair", font=self.fonte, width=12)
        self.bntSair["command"] = self.dSair
        self.bntSair.pack(side=BOTTOM)

    # como eu faço pra essas funcões chamarem as classes que eu quero?

    def dProfessor(self):
        TkProfessores()

    def dAluno(self):
        TkAlunos()

    def dDisciplina(self):
        TkDisciplinas()

    def dTurma(self):
        TkTurmas()

    def dRelatorio(self):
        if self.btnRela["text"] == "Relatório":
            self.btnRela["text"] = "Função indisponível"
        else:
            self.btnRela["text"] = "Relatório"

    def dSair(self):
        exit()


root = Tk()
Application(root)
root.mainloop()
