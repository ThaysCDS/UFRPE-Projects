from Disciplinas import Disciplinas
from tkinter import *


class Application:
    def __init__(self, master=None):
        self.fonte = ("Verdana", "8")

        # criando os layouts para alocar os elementos da interface
        self.container1 = Frame(master)
        self.container1["pady"] = 10
        self.container1.pack()
        self.container2 = Frame(master)
        self.container2["padx"] = 20
        self.container2["pady"] = 5
        self.container2.pack()
        self.container3 = Frame(master)
        self.container3["padx"] = 20
        self.container3["pady"] = 5
        self.container3.pack()
        self.container4 = Frame(master)
        self.container4["padx"] = 20
        self.container4["pady"] = 5
        self.container4.pack()
        self.container5 = Frame(master)
        self.container5["padx"] = 20
        self.container5["pady"] = 10
        self.container5.pack()
        self.container6 = Frame(master)
        self.container6["pady"] = 15
        self.container6.pack()

        # definindo os elementos da interface
        self.titulodisc = Label(self.container1, text="Informe os dados :")
        self.titulodisc["font"] = ("Calibri", "9", "bold")
        self.titulodisc.pack()

        self.lbliddisc = Label(self.container2, text="idDisc:", font=self.fonte, width=10)
        self.lbliddisc.pack(side=LEFT)

        self.txtiddisc = Entry(self.container2)
        self.txtiddisc["width"] = 10
        self.txtiddisc["font"] = self.fonte
        self.txtiddisc.pack(side=LEFT)

        self.btnBuscardisc = Button(self.container2, text="Buscar", font=self.fonte, width=10)
        self.btnBuscardisc["command"] = self.buscarDisciplina
        self.btnBuscardisc.pack(side=RIGHT)

        self.lblnomedisc = Label(self.container3, text="Nome:", font=self.fonte, width=10)
        self.lblnomedisc.pack(side=LEFT)

        self.txtnomedisc = Entry(self.container3)
        self.txtnomedisc["width"] = 25
        self.txtnomedisc["font"] = self.fonte
        self.txtnomedisc.pack(side=LEFT)

        self.lblcoddisc = Label(self.container4, text="Codigo:", font=self.fonte, width=10)
        self.lblcoddisc.pack(side=LEFT)

        self.txtcoddisc = Entry(self.container4)
        self.txtcoddisc["width"] = 25
        self.txtcoddisc["font"] = self.fonte
        self.txtcoddisc.pack(side=LEFT)

        self.bntInsertdisc = Button(self.container5, text="Inserir", font=self.fonte, width=12)
        self.bntInsertdisc["command"] = self.inserirDisciplina
        self.bntInsertdisc.pack(side=LEFT)

        self.bntAlterardisc = Button(self.container5, text="Alterar", font=self.fonte, width=12)
        self.bntAlterardisc["command"] = self.alterarDisciplina
        self.bntAlterardisc.pack(side=LEFT)

        self.bntExcluirdisc = Button(self.container5, text="Excluir", font=self.fonte, width=12)
        self.bntExcluirdisc["command"] = self.excluirDisciplina
        self.bntExcluirdisc.pack(side=LEFT)

        self.bntSair = Button(self.container5, text="Sair", font=self.fonte, width=12)
        self.bntSair["command"] = self.irMenuD
        self.bntSair.pack(side=LEFT)

        self.lblmsgdisc = Label(self.container6, text="")
        self.lblmsgdisc["font"] = ("Verdana", "9", "italic")
        self.lblmsgdisc.pack()

    # agrupando a interface ao banco de dados

    def irMenuD(self):
        exit()

    def inserirDisciplina(self):
        disciplinaa = Disciplinas()

        disciplinaa.nomedisc = self.txtnomedisc.get()
        disciplinaa.codigodisc = self.txtcoddisc.get()

        self.lblmsgdisc["text"] = disciplinaa.insertDisciplina()

        self.txtiddisc.delete(0, END)
        self.txtnomedisc.delete(0, END)
        self.txtcoddisc.delete(0, END)

    def alterarDisciplina(self):
        disciplinaa = Disciplinas()

        disciplinaa.iddisc = self.txtiddisc.get()
        disciplinaa.nomedisc = self.txtnomedisc.get()
        disciplinaa.codigodisc = self.txtcoddisc.get()

        self.lblmsgdisc["text"] = disciplinaa.updateDisciplina()

        self.txtiddisc.delete(0, END)
        self.txtnomedisc.delete(0, END)
        self.txtcoddisc.delete(0, END)

    def excluirDisciplina(self):
        disciplinaa = Disciplinas()

        disciplinaa.iddisc = self.txtiddisc.get()

        self.lblmsgdisc["text"] = disciplinaa.deleteDisciplina()

        self.txtiddisc.delete(0, END)
        self.txtnomedisc.delete(0, END)
        self.txtcoddisc.delete(0, END)

    def buscarDisciplina(self):
        disciplinaa = Disciplinas()

        iddisc = self.txtiddisc.get()

        self.lblmsgdisc["text"] = disciplinaa.selectDisciplina(iddisc)

        self.txtiddisc.delete(0, END)
        self.txtiddisc.insert(INSERT, disciplinaa.iddisc)

        self.txtnomedisc.delete(0, END)
        self.txtnomedisc.insert(INSERT, disciplinaa.nomedisc)

        self.txtcoddisc.delete(0, END)
        self.txtcoddisc.insert(INSERT, disciplinaa.codigodisc)


root = Tk()
Application(root)
root.mainloop()
