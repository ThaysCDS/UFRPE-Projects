# importando módulo do SQlite
import sqlite3


# classe que abriga o Banco de Dados dos Alunos
class DBEscola():

    # conectando o programa ao banco de dados
    def __init__(self):
        self.conexao = sqlite3.connect('cadastros.db')
        self.createTable()

    # criando a tabela de alunos no banco de dados
    def createTable(self):
        c = self.conexao.cursor()

        # definindo as linhas da tabela
        c.execute("""create table if not exists alunos (
                     idaluno integer primary key autoincrement ,
                     nomealuno text,
                     cpfaluno text)""")
        c.execute("""create table if not exists professor (
                     idprof integer primary key autoincrement ,
                     nomeprof text,
                     cpfprof text,
                     departamentoprof text)""")
        c.execute("""create table if not exists disciplinas (
                     iddisc integer primary key autoincrement ,
                     nomedisc text,
                     codigodisc text)""")
        c.execute("""create table if not exists turmas (
                     idturma integer primary key autoincrement,
                     codturma text,
                     periodoturma text,
                     coddiscturma text,
                     cpfprofturma text,
                     cpfalunoturma text)""")

        # , FOREIGN KEY(cpfprof) REFERENCES professor (cpfprof),FOREIGN KEY(codigodisc) REFERENCES disciplinas (codigodisc)

        # c.execute("""create table if not exists turmqa (
        #            idturma integer primary key autoincrement,
        #           codigoturma text,
        #          cpfaluno text)""")
        # ,FOREIGN KEY(codigoturma) REFERENCES turma (codigoturma), FOREIGN KEY(cpfaluno) REFERENCES alunos (cpfaluno)

        self.conexao.commit()
        c.close()
