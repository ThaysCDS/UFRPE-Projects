from Alunos import Alunos
from tkinter import *


class Application:
    def __init__(self, master=None):
        self.fonte = ("Verdana", "8")

        #criando os layouts para alocar os elementos da interface
        self.container1 = Frame(master)
        self.container1["pady"] = 10
        self.container1.pack()
        self.container2 = Frame(master)
        self.container2["padx"] = 20
        self.container2["pady"] = 5
        self.container2.pack()
        self.container3 = Frame(master)
        self.container3["padx"] = 20
        self.container3["pady"] = 5
        self.container3.pack()
        self.container4 = Frame(master)
        self.container4["padx"] = 20
        self.container4["pady"] = 5
        self.container4.pack()
        self.container5 = Frame(master)
        self.container5["padx"] = 20
        self.container5["pady"] = 10
        self.container5.pack()
        self.container6 = Frame(master)
        self.container6["pady"] = 15
        self.container6.pack()


        #definindo os elementos da interface
        self.tituloaluno = Label(self.container1, text="Informe os dados :")
        self.tituloaluno["font"] = ("Calibri", "9", "bold")
        self.tituloaluno.pack()

        self.lblidaluno = Label(self.container2, text="idAluno:", font=self.fonte, width=10)
        self.lblidaluno.pack(side=LEFT)

        self.txtidaluno= Entry(self.container2)
        self.txtidaluno["width"] = 10
        self.txtidaluno["font"] = self.fonte
        self.txtidaluno.pack(side=LEFT)

        self.btnBuscaraluno = Button(self.container2, text="Buscar", font=self.fonte, width=10)
        self.btnBuscaraluno["command"] = self.buscarAluno
        self.btnBuscaraluno.pack(side=RIGHT)

        self.lblnomealuno = Label(self.container3, text="Nome:", font=self.fonte, width=10)
        self.lblnomealuno.pack(side=LEFT)

        self.txtnomealuno = Entry(self.container3)
        self.txtnomealuno["width"] = 25
        self.txtnomealuno["font"] = self.fonte
        self.txtnomealuno.pack(side=LEFT)

        self.lblcpfaluno = Label(self.container4, text="CPF:", font=self.fonte, width=10)
        self.lblcpfaluno.pack(side=LEFT)

        self.txtcpfaluno = Entry(self.container4)
        self.txtcpfaluno["width"] = 25
        self.txtcpfaluno["font"] = self.fonte
        self.txtcpfaluno.pack(side=LEFT)

        self.bntInsertaluno = Button(self.container5, text="Inserir", font=self.fonte, width=12)
        self.bntInsertaluno["command"] = self.inserirAluno
        self.bntInsertaluno.pack(side=LEFT)

        self.bntAlteraraluno = Button(self.container5, text="Alterar", font=self.fonte, width=12)
        self.bntAlteraraluno["command"] = self.alterarAluno
        self.bntAlteraraluno.pack(side=LEFT)

        self.bntExcluiraluno = Button(self.container5, text="Excluir", font=self.fonte, width=12)
        self.bntExcluiraluno["command"] = self.excluirAluno
        self.bntExcluiraluno.pack(side=LEFT)

        self.lblmsgaluno = Label(self.container6, text="")
        self.lblmsgaluno["font"] = ("Verdana", "9", "italic")
        self.lblmsgaluno.pack()


    #agrupando a interface ao banco de dados
    def inserirAluno(self):
        alunoss = Alunos()

        alunoss.nomealuno = self.txtnomealuno.get()
        alunoss.cpfaluno = self.txtcpfaluno.get()

        self.lblmsgaluno["text"] = alunoss.insertAluno()

        self.txtidaluno.delete(0, END)
        self.txtnomealuno.delete(0, END)
        self.txtcpfaluno.delete(0, END)

    def alterarAluno(self):
        alunoss = Alunos()

        alunoss.idaluno = self.txtidaluno.get()
        alunoss.nomealuno = self.txtnomealuno.get()
        alunoss.cpfaluno = self.txtcpfaluno.get()

        self.lblmsgaluno["text"] = alunoss.updateAluno()

        self.txtidaluno.delete(0, END)
        self.txtnomealuno.delete(0, END)
        self.txtcpfaluno.delete(0, END)


    def excluirAluno(self):
        alunoss = Alunos()

        alunoss.idaluno = self.txtidaluno.get()

        self.lblmsgaluno["text"] = alunoss.deleteAluno()

        self.txtidaluno.delete(0, END)
        self.txtnomealuno.delete(0, END)
        self.txtcpfaluno.delete(0, END)


    def buscarAluno(self):
        alunoss = Alunos()

        idaluno = self.txtidaluno.get()

        self.lblmsgaluno["text"] = alunoss.selectAluno(idaluno)

        self.txtidaluno.delete(0, END)
        self.txtidaluno.insert(INSERT, alunoss.idaluno)

        self.txtnomealuno.delete(0, END)
        self.txtnomealuno.insert(INSERT, alunoss.nomealuno)

        self.txtcpfaluno.delete(0, END)
        self.txtcpfaluno.insert(INSERT, alunoss.cpfaluno)


root = Tk()
Application(root)
root.mainloop()